/*Get the theme select element and the root element
*/
export const themeSelect = document.querySelector('[data-settings-theme]');
/**const root = document.documentElement;
Define the color values for the day and night themes
*/
export const themeMode = {
  day: {
    dark: '10, 10, 20',
    light: '255, 255, 255',
  },
  night: {
    dark: '255, 255, 255',
    light: '10, 10, 20',
  }
}
export const form = document.getElementById('settings');
 /*const themeSelect = document.querySelector('[data-settings-theme]');
 *Night mode or Day mode can be used according the preferance you are choosing
 *setting theme mode
 */
 form.addEventListener('submit', (event) => {
   event.preventDefault();
   const theme = themeSelect.value;
   document.documentElement.style.setProperty('--color-dark', themeMode[theme].dark);
   document.documentElement.style.setProperty('--color-light', themeMode[theme].light);
 });
 /*Initialize theme based on user's OS theme preference
 *Which type of device can be used
 */
 export const prefersDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
 export const initialTheme = prefersDarkMode ? 'night' : 'day';
 document.documentElement.style.setProperty('--color-dark', themeMode[initialTheme].dark);
 document.documentElement.style.setProperty('--color-light', themeMode[initialTheme].light)
